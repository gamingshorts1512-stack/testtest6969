/* =============================================
   VIXRA STUDIO — Main JavaScript
   ============================================= */

/* ---------- CUSTOM CURSOR ---------- */
const isTouchDevice = () =>
  window.matchMedia('(hover: none)').matches || window.innerWidth <= 900;

const cursor = document.getElementById('cursor');
const cursorRing = document.getElementById('cursorRing');
let mx = 0, my = 0, rx = 0, ry = 0;

if (!isTouchDevice()) {
  document.addEventListener('mousemove', e => {
    mx = e.clientX;
    my = e.clientY;
    cursor.style.left = mx - 6 + 'px';
    cursor.style.top  = my - 6 + 'px';
  });

  function animateRing() {
    rx += (mx - rx) * 0.12;
    ry += (my - ry) * 0.12;
    cursorRing.style.left = rx - 18 + 'px';
    cursorRing.style.top  = ry - 18 + 'px';
    requestAnimationFrame(animateRing);
  }
  animateRing();

  document.querySelectorAll('a, button, .service-card, .portfolio-item, .testi-card')
    .forEach(el => {
      el.addEventListener('mouseenter', () => {
        cursor.style.transform    = 'scale(2)';
        cursorRing.style.transform = 'scale(1.5)';
      });
      el.addEventListener('mouseleave', () => {
        cursor.style.transform    = 'scale(1)';
        cursorRing.style.transform = 'scale(1)';
      });
    });
} else {
  cursor.style.display    = 'none';
  cursorRing.style.display = 'none';
  document.body.style.cursor = 'auto';
}

/* ---------- PARTICLES CANVAS ---------- */
const canvas = document.getElementById('particles-canvas');
const ctx    = canvas.getContext('2d');
let particles = [];

function resizeCanvas() {
  canvas.width  = canvas.offsetWidth;
  canvas.height = canvas.offsetHeight;
}
resizeCanvas();
window.addEventListener('resize', resizeCanvas);

for (let i = 0; i < 80; i++) {
  particles.push({
    x:  Math.random() * canvas.width,
    y:  Math.random() * canvas.height,
    vx: (Math.random() - 0.5) * 0.4,
    vy: (Math.random() - 0.5) * 0.4,
    r:  Math.random() * 1.5 + 0.5,
    a:  Math.random() * 0.5 + 0.1,
  });
}

function drawParticles() {
  ctx.clearRect(0, 0, canvas.width, canvas.height);

  particles.forEach(p => {
    p.x += p.vx;
    p.y += p.vy;
    if (p.x < 0 || p.x > canvas.width)  p.vx *= -1;
    if (p.y < 0 || p.y > canvas.height) p.vy *= -1;

    ctx.beginPath();
    ctx.arc(p.x, p.y, p.r, 0, Math.PI * 2);
    ctx.fillStyle = `rgba(0,245,228,${p.a})`;
    ctx.fill();
  });

  // Draw connection lines between nearby particles
  for (let i = 0; i < particles.length; i++) {
    for (let j = i + 1; j < particles.length; j++) {
      const dx = particles[i].x - particles[j].x;
      const dy = particles[i].y - particles[j].y;
      const d  = Math.sqrt(dx * dx + dy * dy);
      if (d < 120) {
        ctx.beginPath();
        ctx.moveTo(particles[i].x, particles[i].y);
        ctx.lineTo(particles[j].x, particles[j].y);
        ctx.strokeStyle = `rgba(0,102,255,${0.08 * (1 - d / 120)})`;
        ctx.lineWidth   = 0.5;
        ctx.stroke();
      }
    }
  }
  requestAnimationFrame(drawParticles);
}
drawParticles();

/* ---------- SCROLL REVEAL ---------- */
const revealObserver = new IntersectionObserver(entries => {
  entries.forEach((entry, i) => {
    if (entry.isIntersecting) {
      setTimeout(() => entry.target.classList.add('visible'), i * 80);
    }
  });
}, { threshold: 0.1 });

document.querySelectorAll('.reveal').forEach(el => revealObserver.observe(el));

/* ---------- PORTFOLIO FILTER ---------- */
function filterPortfolio(cat, btn) {
  document.querySelectorAll('.filter-btn').forEach(b => b.classList.remove('active'));
  btn.classList.add('active');

  document.querySelectorAll('.portfolio-item').forEach(item => {
    const show = cat === 'all' || item.dataset.cat === cat;
    item.style.display = show ? 'block' : 'none';
    if (show) item.style.animation = 'fadeUp 0.5s ease both';
  });
}

/* ---------- CHATBOT ---------- */
const chatReplies = [
  "That sounds like an exciting project! I'd love to help. 🎨",
  "Great question! You can share more details via the contact form below.",
  "We typically deliver within 2–5 business days depending on scope.",
  "Pricing starts from $50 for thumbnails, $150 for logos, and $200+ for video editing.",
  "Unlimited revisions are included with every project! ✦",
  "Yes, we work with creators, brands, agencies, and startups worldwide.",
];
let replyIdx = 0;

function toggleChat() {
  const panel = document.getElementById('chatPanel');
  panel.classList.toggle('open');
  document.getElementById('chatFab').textContent =
    panel.classList.contains('open') ? '✕' : '💬';
}

function sendChat() {
  const input = document.getElementById('chatInput');
  const msg   = input.value.trim();
  if (!msg) return;

  const msgs = document.getElementById('chatMessages');

  const userEl = document.createElement('div');
  userEl.className   = 'chat-msg user';
  userEl.textContent = msg;
  msgs.appendChild(userEl);
  input.value = '';

  setTimeout(() => {
    const botEl = document.createElement('div');
    botEl.className   = 'chat-msg bot';
    botEl.textContent = chatReplies[replyIdx++ % chatReplies.length];
    msgs.appendChild(botEl);
    msgs.scrollTop = msgs.scrollHeight;
  }, 600);

  msgs.scrollTop = msgs.scrollHeight;
}

/* ---------- CONTACT FORM ---------- */
function handleSubmit(e) {
  e.preventDefault();
  const btn = e.target.querySelector('button[type=submit]');
  btn.textContent       = '✓ Message Sent!';
  btn.style.background  = 'linear-gradient(135deg, #00c853, #00e676)';
  setTimeout(() => {
    btn.textContent      = 'Send Message ✦';
    btn.style.background = '';
  }, 3000);
}

/* ---------- MOBILE NAV ---------- */
function toggleMobileNav() {
  const nav = document.getElementById('mobileNav');
  const btn = document.getElementById('hamburger');
  nav.classList.toggle('open');
  btn.classList.toggle('open');
  document.body.style.overflow = nav.classList.contains('open') ? 'hidden' : '';
}

function closeMobileNav() {
  document.getElementById('mobileNav').classList.remove('open');
  document.getElementById('hamburger').classList.remove('open');
  document.body.style.overflow = '';
}

/* ---------- NAV SCROLL SHRINK ---------- */
window.addEventListener('scroll', () => {
  const isMobile = window.innerWidth <= 900;
  document.getElementById('navbar').style.padding = window.scrollY > 40
    ? (isMobile ? '10px 20px' : '12px 60px')
    : (isMobile ? '14px 20px' : '20px 60px');
});

/* ---------- 3D LAPTOP PARALLAX (desktop only) ---------- */
if (!isTouchDevice()) {
  document.addEventListener('mousemove', e => {
    const laptop = document.querySelector('.laptop');
    if (!laptop) return;
    const cx  = window.innerWidth  / 2;
    const cy  = window.innerHeight / 2;
    const rx2 = ((e.clientY - cy) / cy) * 4;
    const ry2 = ((e.clientX - cx) / cx) * -8;
    laptop.style.transform = `rotateY(${-18 + ry2}deg) rotateX(${8 + rx2}deg)`;
  });
}
