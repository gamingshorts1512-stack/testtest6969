# VIXRA Studio — Creative Agency Website

A premium, fully responsive single-page website for a freelance creative agency. Built with pure HTML, CSS, and vanilla JavaScript — no frameworks, no dependencies.

## Live Demo

> Deploy to GitHub Pages and paste your link here.

---

## Features

- Dark luxury theme with neon cyan / blue / purple accents
- Glassmorphism UI cards with blur and soft borders
- Animated particle canvas with connecting lines
- 3D floating laptop with live video-editing timeline (desktop)
- Custom glowing cursor with smooth ring follower (desktop)
- Smooth scroll-triggered reveal animations
- Hamburger menu with full-screen mobile nav drawer
- Portfolio grid with category filter (All / Video / Logos / Banners)
- Floating chatbot with multi-reply responses
- Contact form with success state feedback
- Fully responsive — mobile, tablet, desktop

---

## Project Structure

```
vixra-studio/
├── index.html          # Main HTML — all sections
├── css/
│   ├── style.css       # All styles, components, animations
│   └── responsive.css  # Mobile & tablet breakpoints
├── js/
│   └── main.js         # Cursor, particles, chatbot, nav, form
└── README.md
```

---

## How to Deploy on GitHub Pages

1. **Create a new repository** on GitHub (e.g. `vixra-studio`)
2. **Upload all files** — keeping the folder structure intact:
   ```
   index.html
   css/style.css
   css/responsive.css
   js/main.js
   ```
3. Go to your repo → **Settings** → **Pages**
4. Under **Source**, select `main` branch and `/ (root)`
5. Click **Save** — your site will be live at:
   ```
   https://YOUR-USERNAME.github.io/vixra-studio/
   ```

---

## How to Customise

| What to change | Where |
|---|---|
| Brand name | `index.html` — search `VIXRA` |
| Hero headline | `index.html` — `<h1>` in `#hero` |
| Services | `index.html` — `#services` section |
| Portfolio items | `index.html` — `#portfolio` section |
| Client names | `index.html` — `#clients` section |
| About text & stats | `index.html` — `#about` section |
| Testimonials | `index.html` — `#testimonials` section |
| Social links | `index.html` — `#contact` section |
| Colors / fonts | `css/style.css` — `:root` variables |
| Chatbot replies | `js/main.js` — `chatReplies` array |

---

## Fonts Used

- **Playfair Display** — headings (Google Fonts)
- **Outfit** — body text (Google Fonts)

---

## Browser Support

Works in all modern browsers: Chrome, Firefox, Safari, Edge.

---

## License

Free to use and customise for personal and commercial projects.
